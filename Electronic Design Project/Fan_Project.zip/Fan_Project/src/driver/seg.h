#ifndef __SEG_H__
#define __SEG_H__

#include <REG52.H>

void seg_init(void);
void seg_disp(unsigned char loc, unsigned char num, bit point);

#endif
