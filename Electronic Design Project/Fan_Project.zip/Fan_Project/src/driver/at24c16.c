#include "at24c16.h"
#include "iic.h"

void at24c16_writebyte(unsigned char WordAddress, Data)
{
    I2C_Start();
    I2C_SendByte(AT24C16_WRITE);
    I2C_ReceiveAck();
    I2C_SendByte(WordAddress);
    I2C_ReceiveAck();
    I2C_SendByte(Data);
    I2C_ReceiveAck();
    I2C_Stop();
    I2C_Delay(255);
    I2C_Delay(255);
}

unsigned char at24c16_readbyte(unsigned char WordAddress)
{
    unsigned char Data;
    I2C_Start();
    I2C_SendByte(AT24C16_WRITE);
    I2C_ReceiveAck();
    I2C_SendByte(WordAddress);
    I2C_ReceiveAck();

    I2C_Start();
    I2C_SendByte(AT24C16_READ);
    I2C_ReceiveAck();
    Data = I2C_ReceiveByte();
    I2C_SendAck(1);
    I2C_Stop();
    return Data;
}
