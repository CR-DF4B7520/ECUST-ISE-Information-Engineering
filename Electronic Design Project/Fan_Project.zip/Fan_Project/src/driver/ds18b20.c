#include "ds18b20.h"
#include "intrins.h"

sbit DQ = P1 ^ 3;

unsigned char OneWire_Init(void)
{

    unsigned char i;
    unsigned char AckBit;
    DQ = 1;
    DQ = 0;
    i = 247;
    while (--i)
        ; // Delay 500us
    DQ = 1;
    i = 32;
    while (--i)
        ; // Delay 70us
    AckBit = DQ;
    i = 247;
    while (--i)
        ; // Delay 500us
    return AckBit;
}

void OneWire_SendBit(unsigned char Bit)
{
    unsigned char i;
    DQ = 0;
    i = 4;
    while (--i)
        ; // Delay 10us
    DQ = Bit;
    i = 24;
    while (--i)
        ; // Delay 50us
    DQ = 1;
}

unsigned char OneWire_ReceiveBit(void)
{
    unsigned char i;
    unsigned char Bit;
    DQ = 0;
    i = 2;
    while (--i)
        ; // Delay 5us
    DQ = 1;
    i = 2;
    while (--i)
        ; // Delay 5us
    Bit = DQ;
    i = 24;
    while (--i)
        ; // Delay 50us
    return Bit;
}

void OneWire_SendByte(unsigned char Byte)
{
    unsigned char i;
    for (i = 0; i < 8; i++)
    {
        OneWire_SendBit(Byte & (0x01 << i));
    }
}

unsigned char OneWire_ReceiveByte(void)
{
    unsigned char i;
    unsigned char Byte = 0x00;
    for (i = 0; i < 8; i++)
    {
        if (OneWire_ReceiveBit())
        {
            Byte |= (0x01 << i);
        }
    }
    return Byte;
}
float read_temperature(void)
{
    unsigned char low, high;
    OneWire_Init();
    OneWire_SendByte(0xcc);
    OneWire_SendByte(0x44);
    OneWire_Init();
    OneWire_SendByte(0xcc);
    OneWire_SendByte(0xbe);
    low = OneWire_ReceiveByte();
    high = OneWire_ReceiveByte();
    return (float)((high << 8 | low) * 0.0625);
}