#include "hd7279.h"

sbit cs = P1 ^ 4;
sbit clk = P1 ^ 5;
sbit dat = P1 ^ 7;
sbit key = P1 ^ 6;

void send_byte(unsigned char cmd)
{
    unsigned char i;
    cs = 0;
    long_delay();
    for (i = 0; i < 8; i++)
    {
        if (cmd & 0x80)
        {
            dat = 1;
        }
        else
        {
            dat = 0;
        }
        clk = 1;
        short_delay();
        clk = 0;
        short_delay();
        cmd = cmd * 2;
    }
    dat = 0;
}

unsigned char receive_byte(void)
{
    unsigned char i, in_byte = 0;
    dat = 1; // jV()WX
    short_delay();
    for (i = 0; i < 8; i++)
    {
        clk = 1;
        short_delay();
        in_byte = in_byte * 2;
        if (dat)
        {
            in_byte = in_byte | 0x01;
        }
        clk = 0;
        short_delay();
    }
    dat = 0;
    return (in_byte);
}

void write_7279(unsigned char cmd, unsigned char dta)
{
    send_byte(cmd);
    send_byte(dta);
}

unsigned char read_7279(unsigned char command)
{
    EA = 0;
    send_byte(command);
    EA = 1;
    return (receive_byte());
}

void long_delay(void)
{
    unsigned char i;
    for (i = 0; i < 0x20; i++)
        ;
}

void short_delay(void)
{
    unsigned char i;
    for (i = 0; i < 5; i++)
        ;
}
