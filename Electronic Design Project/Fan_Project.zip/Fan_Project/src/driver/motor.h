#ifndef _MOTOR_H_
#define _MOTOR_H_

#include <REG52.H>
void Motor(bit enable);
unsigned char pwm_calculate(unsigned int temp_100x, unsigned int temp_up_100x, unsigned int temp_down_100x);
#endif // !_MOTOR_H_
