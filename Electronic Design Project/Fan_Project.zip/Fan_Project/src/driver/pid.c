#include "pid.h"
#include <stdio.h>
extern unsigned char k_para[3];
extern float error_record;
extern unsigned char pid_duty_base;

unsigned char pid_calculate(unsigned int temp_100x, unsigned int pid_set_temp_100x)
{
    float error;
    float error_integration;
    float error_diff;
    float last_error;
    int new_cycle_duty;

    // printf("IN:%u,%u,b%bu\r\n", temp_100x, pid_set_temp_100x, pid_duty_base);

    if (temp_100x < pid_set_temp_100x)
    {
        error_record = 0;
        return 0;
    }

    error = (float)(temp_100x - pid_set_temp_100x) / 100.0;
    // 保存上次误差用于微分计算
    last_error = error_record;
    error_integration = last_error + error;

    // 积分限幅（抗积分饱和）
    if (error_integration > 10.0)
        error_integration = 10.0;

    error_diff = error - last_error;

    // 位置式PID计算
    new_cycle_duty = pid_duty_base + k_para[0] * error + k_para[1] * error_integration + k_para[2] * error_diff;

    if (new_cycle_duty < 0)
        new_cycle_duty = 0;
    else if (new_cycle_duty >= 100)
        new_cycle_duty = 99;

    // 保存积分项（而不是误差）
    error_record = error_integration;

    // printf("OUT:%d\r\n", new_cycle_duty);
    return new_cycle_duty;
}