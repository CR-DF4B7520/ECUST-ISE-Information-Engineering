#include "seg.h"
#include "hd7279.h"
// 0--9 10-灭 11-- 12--T 13-P  14-r 15-u 16-n 17-C 18-o 19-A 20-b 21-F 22-d

xdata unsigned char seg_num[] = {0xFC, 0x44, 0x79, 0x5D, 0xC5, 0x9D, 0xBD, 0x54, 0xFD, 0xDD, 0x00,
                                 0x01, 0xA9, 0xF1, 0x21, 0x2c, 0x25, 0xb8, 0x2d, 0Xf5, 0xad, 0xb1, 0x6d};
xdata unsigned char seg_loc[8] = {0x90, 0x91, 0x92, 0x93, 0x94, 0x95, 0x96, 0x97};

void seg_init(void)
{
    send_byte(CMD_RESET);
}
void seg_disp(unsigned char loc, unsigned char num, bit point)
{
    if (point)
        write_7279(seg_loc[loc], seg_num[num] | 0x02);
    else
        write_7279(seg_loc[loc], seg_num[num]);
}
