#ifndef __DS18B20_H__
#define __DS18B20_H__

#include <REG52.H>
float read_temperature(void);
#endif
