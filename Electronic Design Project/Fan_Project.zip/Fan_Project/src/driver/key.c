#include "key.h"
#include "hd7279.h"
unsigned char key_read(void)
{
    unsigned char key_num = read_7279(CMD_READ);
    if (key_num == 0xFF)
        key_num = 0;
    else if (key_num == 0x3B)
        key_num = 1;
    else if (key_num == 0x3A)
        key_num = 2;
    else if (key_num == 0x39)
        key_num = 3;
    else if (key_num == 0x38)
        key_num = 4;

    return key_num;
}
