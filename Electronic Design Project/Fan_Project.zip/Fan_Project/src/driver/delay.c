#include "delay.h"
/*
void Delay750ms() //@11.0592MHz
{
    unsigned char i, j, k;
    i = 6;
    j = 70;
    k = 181;
    do
    {
        do
        {
            while (--k)
                ;
        } while (--j);
    } while (--i);
}
*/
