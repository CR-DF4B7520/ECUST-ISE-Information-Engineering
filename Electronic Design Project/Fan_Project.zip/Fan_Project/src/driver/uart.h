#include <REG52.H>
void UartInit(void);