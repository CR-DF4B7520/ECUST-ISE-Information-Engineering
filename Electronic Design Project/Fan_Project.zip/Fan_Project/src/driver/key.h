#ifndef __KEY_H__
#define __KEY_H__

#include <REG52.H>
#include "hd7279.h"
#include "uart.h"

unsigned char key_read(void);
#endif
