#ifndef __AT24C16_H__
#define __AT24C16_H__

#include <REG52.H>

#define AT24C16_WRITE 0xA0
#define AT24C16_READ 0xA1

void at24c16_writebyte(unsigned char WordAddress, Data);
unsigned char at24c16_readbyte(unsigned char WordAddress);
bit at24c16_init(unsigned char addr, unsigned char eep_lock);
#endif
