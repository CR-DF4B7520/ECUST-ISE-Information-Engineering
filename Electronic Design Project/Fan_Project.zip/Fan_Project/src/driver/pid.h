#ifndef __PID_H__
#define __PID_H__
extern unsigned char k_para[3];
extern float error_record;
extern unsigned char pid_duty_base;
unsigned char pid_calculate(unsigned int temp_100x, unsigned int pid_set_temp_100x);
#endif