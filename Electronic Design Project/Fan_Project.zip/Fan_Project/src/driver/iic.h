#ifndef __DS18B20_H__
#define __DS18B20_H__

#include <REG52.H>
void I2C_Start();
void I2C_Stop();
void I2C_SendByte(unsigned char Byte);
unsigned char I2C_ReceiveByte();
void I2C_SendAck(unsigned char AckBit);
unsigned char I2C_ReceiveAck();
void I2C_Delay(unsigned char n);
#endif