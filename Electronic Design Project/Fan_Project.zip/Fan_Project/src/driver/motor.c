#include <motor.h>
sbit motor_run = P1 ^ 2;
void Motor(bit enable)
{
    if (enable)
    {
        motor_run = 1;
    }
    else
    {
        motor_run = 0;
    }
}

unsigned char pwm_calculate(unsigned int temp_100x, unsigned int temp_up_100x, unsigned int temp_down_100x)
{
    float temp;
    if (temp_100x > temp_up_100x)
    {
        return 100;
    }
    else if (temp_100x < temp_down_100x)
    {
        return 0;
    }
    else
    {
        temp = (float)(temp_100x - temp_down_100x) / (float)(temp_up_100x - temp_down_100x);
        return (temp * 50 + 50);
    }
}
