#include <REG52.H>
#include <STDIO.H>
#include <intrins.h>
#include <string.h>
#include <stdio.h>
#include "uart.h"
#include "hd7279.h"
#include "key.h"
#include "seg.h"
#include "ds18b20.h"
#include "at24c16.h"
#include "motor.h"
#include "delay.h"
#include "pid.h"

idata unsigned long int uwtick;
idata unsigned char key_val, key_down, key_up, key_old;
idata unsigned char uart_buf[10];
idata unsigned char uart_index = 0;
idata unsigned char uart_tick;
idata unsigned char seg_pos;
idata unsigned char seg_buf[8] = {10, 10, 10, 10, 10, 10, 10, 10};
idata unsigned char seg_point[8] = {0, 0, 0, 0, 0, 0, 0, 0};
idata unsigned int temp_100x;
idata unsigned char pwm_period = 0; // 0---9
idata unsigned char pwm_compare = 0;
unsigned char seg_disp_mode;   // 0--tp- 1--run- 2--Con- 3-PA- 4--pid
bit temp_disp_mode;            // 温度界面显示 0--主页面 1--温度子页面
unsigned char motor_test_disp; // 0--主页面 1--电机工艺菜单选择界面 2--电机密码输入界面 3--电机测试运行动态界面
bit motor_speed_disp;          // 0--电机调速主菜单 1--电机调试状态显示界面
unsigned char current_password[4] = {1, 0, 1, 0};
unsigned char input_password[4] = {10, 10, 10, 10};
unsigned char input_password_index = 0;
unsigned char pa_disp_mode;
unsigned char eeproom_lock = 3;
unsigned char read_flag = 0;
bit key1_long_press_flag;
bit key2_long_press_flag;
unsigned int timer1000ms;
xdata unsigned char pwm_set[10] = {7, 10, 14, 26, 47, 52, 62, 78, 84, 90};
unsigned char pwm_set_index = 0;
xdata unsigned int temp_up_100x = 3000;
xdata unsigned int temp_down_100x = 2600;
xdata unsigned int temp_up_100x_ctrl;
xdata unsigned int temp_down_100x_ctrl;
xdata unsigned int pid_set_temp_100x = 2600;
xdata unsigned int pid_set_temp_100x_ctrl;
unsigned char pid_disp_mode; // 0--pid主页面  1--pid温度显示
unsigned char k_para[3] = {60, 1, 1};
float error_record;
unsigned char pid_duty_base = 15;
bit pid_temp_ready; // 温度更新标志：置1表示有新温度采样，供PID计算一次

void key_proc(void)
{
    key_val = key_read();                     // 实时读取键码值
    key_down = key_val & (key_old ^ key_val); // 捕捉按键下降沿
    key_up = ~key_val & (key_old ^ key_val);  // 捕捉按键上降沿
    key_old = key_val;                        // 辅助扫描变量
    switch (seg_disp_mode)
    {
    case 0: // Tp- 温度显示
    {
        if (key_down == 1)
        {
            seg_disp_mode = 1;
            motor_test_disp = 0;
        }
        else if (key_down == 2)
        {
            seg_disp_mode = 4;
            pid_disp_mode = 0;
        }
        if (temp_disp_mode == 0)
        {
            if (key_down == 4)
            {
                temp_disp_mode = 1;
            }
        }
        else if (temp_disp_mode == 1)
        {
            if (key_down == 3)
            {
                temp_disp_mode = 0;
            }
        }
    }
    break;
    case 1: // run- 电机测试密码
    {
        if (motor_test_disp == 0)
        {
            if (key_down == 1)
            {
                seg_disp_mode = 2;
                motor_speed_disp = 0;
            }
            if (key_down == 2)
            {
                seg_disp_mode = 0;
                temp_disp_mode = 0;
            }
            if (key_down == 4)
            {
                motor_test_disp = 1;
            }
        }
        else if (motor_test_disp == 1)
        {
            if (key_down == 1)
            {
                pwm_set_index = (++pwm_set_index) % 10;
            }
            if (key_down == 2)
            {
                pwm_set_index = (pwm_set_index == 0) ? 9 : (pwm_set_index - 1);
            }
            if (key_down == 3)
            {
                motor_test_disp = 0;
            }
            if (key_down == 4)
            {
                motor_test_disp = 2;
            }
        }
        else if (motor_test_disp == 2)
        {
            if (input_password_index < 4)
            {
                if (key_down == 1)
                {
                    input_password[input_password_index] = 0;
                    input_password_index++;
                }
                else if (key_down == 2)
                {
                    input_password[input_password_index] = 1;
                    input_password_index++;
                }
            }
            if (key_down == 3)
            {
                input_password_index = 0;
                memset(input_password, 10, 4);
                motor_test_disp = 1;
            }
            else if (key_down == 4)
            {
                if (memcmp(input_password, current_password, 4) == 0)
                {
                    motor_test_disp = 3;
                }
                else
                {
                    motor_test_disp = 1;
                }
                input_password_index = 0;
                memset(input_password, 10, 4);
            }
        }
        else if (motor_test_disp == 3)
        {
            pwm_compare = pwm_set[pwm_set_index];
            if (key_down == 3)
            {
                motor_test_disp = 1;
                pwm_compare = 0;
            }
            if (key_down == 4)
            {
                motor_test_disp = 0;
                pwm_compare = 0;
            }
        }
    }
    break;
    case 2: // Con- 电机调速
    {
        if (key_down == 1)
        {
            seg_disp_mode = 3;
            pa_disp_mode = 0;
        }
        else if (key_down == 2)
        {
            seg_disp_mode = 1;
            motor_test_disp = 0;
        }
        if (motor_speed_disp == 0)
        {
            if (key_down == 4)
            {
                motor_speed_disp = 1;
            }
        }
        else if (motor_speed_disp == 1)
        {
            if (key_down == 3)
            {
                motor_speed_disp = 0;
                pwm_compare = 0;
            }
        }
        if (motor_speed_disp == 1)
        {
            pwm_compare = pwm_calculate(temp_100x, temp_up_100x, temp_down_100x);
        }
    }
    break;
    case 3: // run- 电机测试
    {
        if (pa_disp_mode == 0)
        {
            if (key_down == 1)
            {
                seg_disp_mode = 4;
                pid_disp_mode = 0;
            }
            if (key_down == 2)
            {
                seg_disp_mode = 2;
                motor_speed_disp = 0;
            }
            if (key_down == 4)
            {
                pa_disp_mode = 1;
            }
        }
        else if (pa_disp_mode == 1)
        {
            if (key_down == 1)
            {
                pa_disp_mode = 2;
            }
            if (key_down == 2)
            {
                pa_disp_mode = 9;
            }
            if (key_down == 3)
            {
                pa_disp_mode = 0;
            }
            if (key_down == 4)
            {
                pa_disp_mode = 3;
            }
        }
        else if (pa_disp_mode == 2)
        {
            if (key_down == 1)
            {
                pa_disp_mode = 9;
            }
            if (key_down == 2)
            {
                pa_disp_mode = 1;
            }
            if (key_down == 3)
            {
                pa_disp_mode = 0;
            }
            if (key_down == 4)
            {
                pa_disp_mode = 5;
            }
        }
        else if (pa_disp_mode == 3)
        {
            if (key_down == 1)
            {
                pwm_set_index = (++pwm_set_index) % 10;
            }
            if (key_down == 2)
            {
                pwm_set_index = (pwm_set_index == 0) ? 9 : (pwm_set_index - 1);
            }
            if (key_down == 3)
            {
                pa_disp_mode = 1;
            }
            if (key_down == 4)
            {
                pa_disp_mode = 4;
            }
        }
        else if (pa_disp_mode == 4)
        {
            if (key_down == 1)
            {
                key1_long_press_flag = 1;
            }
            if (timer1000ms >= 1000)
            {
                if (key_old == 1)
                {
                    pwm_set[pwm_set_index] = (pwm_set[pwm_set_index] == 0) ? 0 : (pwm_set[pwm_set_index] - 1);
                }
            }
            if (key_up == 1)
            {
                if (timer1000ms < 1000)
                {
                    pwm_set[pwm_set_index] = (pwm_set[pwm_set_index] == 0) ? 0 : (pwm_set[pwm_set_index] - 1);
                }
                key1_long_press_flag = 0;
                timer1000ms = 0;
            }
            if (key_down == 2)
            {
                key2_long_press_flag = 1;
            }
            if (timer1000ms >= 1000)
            {
                if (key_old == 2)
                {
                    pwm_set[pwm_set_index] = (pwm_set[pwm_set_index] == 99) ? 99 : (pwm_set[pwm_set_index] + 1);
                }
            }
            if (key_up == 2)
            {
                if (timer1000ms < 1000)
                {
                    pwm_set[pwm_set_index] = (pwm_set[pwm_set_index] == 99) ? 99 : (pwm_set[pwm_set_index] + 1);
                }
                key2_long_press_flag = 0;
                timer1000ms = 0;
            }
            if (key_down == 3)
            {
                pa_disp_mode = 3;
            }
        }
        else if (pa_disp_mode == 5)
        {
            if (key_down == 1)
            {
                pa_disp_mode = 6;
            }
            if (key_down == 3)
            {
                pa_disp_mode = 2;
            }
            if (key_down == 4)
            {
                temp_down_100x_ctrl = temp_down_100x;
                pa_disp_mode = 7;
            }
        }
        else if (pa_disp_mode == 6)
        {
            if (key_down == 2)
            {
                pa_disp_mode = 5;
            }
            if (key_down == 3)
            {
                pa_disp_mode = 5;
            }
            if (key_down == 4)
            {
                temp_up_100x_ctrl = temp_up_100x;
                pa_disp_mode = 8;
            }
        }
        else if (pa_disp_mode == 7)
        {
            if (key_down == 1)
            {
                key1_long_press_flag = 1;
            }
            if (timer1000ms >= 1000)
            {
                if (key_old == 1)
                {
                    temp_down_100x_ctrl = (temp_down_100x_ctrl == 0) ? 0 : (temp_down_100x_ctrl - 100);
                }
            }
            if (key_up == 1)
            {
                if (timer1000ms < 1000)
                {
                    temp_down_100x_ctrl = (temp_down_100x_ctrl == 0) ? 0 : (temp_down_100x_ctrl - 100);
                }
                key1_long_press_flag = 0;
                timer1000ms = 0;
            }
            if (key_down == 2)
            {
                key2_long_press_flag = 1;
            }
            if (timer1000ms >= 1000)
            {
                if (key_old == 2)
                {
                    temp_down_100x_ctrl = (temp_down_100x_ctrl == 9900) ? 9900 : (temp_down_100x_ctrl + 100);
                }
            }
            if (key_up == 2)
            {
                if (timer1000ms < 1000)
                {
                    temp_down_100x_ctrl = (temp_down_100x_ctrl == 9900) ? 9900 : (temp_down_100x_ctrl + 100);
                }
                key2_long_press_flag = 0;
                timer1000ms = 0;
            }
            if (key_down == 3)
            {
                pa_disp_mode = 5;
            }
            if (key_down == 4)
            {
                if (temp_down_100x_ctrl < temp_up_100x_ctrl)
                {
                    temp_down_100x = temp_down_100x_ctrl;
                    at24c16_writebyte(0x01, (unsigned char)(temp_down_100x / 100));
                    at24c16_writebyte(0x06, eeproom_lock);
                    printf("%bu", (unsigned char)(temp_down_100x / 100));
                }
                else
                {
                    temp_down_100x_ctrl = temp_down_100x;
                }
                pa_disp_mode = 5;
            }
            if (key_down == 3)
            {
                temp_down_100x_ctrl = temp_down_100x;
                pa_disp_mode = 5;
            }
        }
        else if (pa_disp_mode == 8)
        {

            if (key_down == 1)
            {
                key1_long_press_flag = 1;
            }
            if (timer1000ms >= 1000)
            {
                if (key_old == 1)
                {
                    temp_up_100x_ctrl = (temp_up_100x_ctrl == 9900) ? 9900 : (temp_up_100x_ctrl + 100);
                }
            }
            if (key_up == 1)
            {
                if (timer1000ms < 1000)
                {
                    temp_up_100x_ctrl = (temp_up_100x_ctrl == 9900) ? 9900 : (temp_up_100x_ctrl + 100);
                }
                key1_long_press_flag = 0;
                timer1000ms = 0;
            }
            if (key_down == 2)
            {
                key2_long_press_flag = 1;
            }
            if (timer1000ms >= 1000)
            {
                if (key_old == 2)
                {
                    temp_up_100x_ctrl = (temp_up_100x_ctrl == 0) ? 0 : (temp_up_100x_ctrl - 100);
                }
            }
            if (key_up == 2)
            {
                if (timer1000ms < 1000)
                {
                    temp_up_100x_ctrl = (temp_up_100x_ctrl == 0) ? 0 : (temp_up_100x_ctrl - 100);
                }
                key2_long_press_flag = 0;
                timer1000ms = 0;
            }
            if (key_down == 3)
            {
                temp_up_100x_ctrl = temp_up_100x;
                pa_disp_mode = 6;
            }
            if (key_down == 4)
            {
                if (temp_up_100x_ctrl > temp_down_100x_ctrl)
                {
                    temp_up_100x = temp_up_100x_ctrl;
                    at24c16_writebyte(0x02, (unsigned char)(temp_up_100x / 100));
                    at24c16_writebyte(0x07, eeproom_lock);
                }
                else
                {
                    temp_up_100x_ctrl = temp_up_100x;
                }
                pa_disp_mode = 6;
            }
        }
        else if (pa_disp_mode == 9)
        {
            if (key_down == 1)
            {
                pa_disp_mode = 1;
            }
            if (key_down == 2)
            {
                pa_disp_mode = 2;
            }
            if (key_down == 4)
            {
                pid_set_temp_100x_ctrl = pid_set_temp_100x;
                pa_disp_mode = 10;
            }
        }
        else if (pa_disp_mode == 10)
        {
            if (key_down == 4)
            {
                pid_set_temp_100x = pid_set_temp_100x_ctrl;
                at24c16_writebyte(0x03, (unsigned char)(pid_set_temp_100x / 100)); // 整数度
                at24c16_writebyte(0x04, (unsigned char)(pid_set_temp_100x % 100)); // 小数(0.01单位)
                at24c16_writebyte(0x07, eeproom_lock);
                pa_disp_mode = 9;
            }
            if (key_down == 3)
            {
                pid_set_temp_100x_ctrl = pid_set_temp_100x;
                pa_disp_mode = 9;
            }
            if (key_down == 1)
            {
                pid_set_temp_100x_ctrl = (pid_set_temp_100x_ctrl == 0) ? 0 : (pid_set_temp_100x_ctrl - 10);
            }
            if (key_down == 2)
            {
                pid_set_temp_100x_ctrl = (pid_set_temp_100x_ctrl == 9990) ? 9990 : (pid_set_temp_100x_ctrl + 10);
            }
        }
    }
    break;
    case 4: // pid- 恒温控制
    {
        if (pid_disp_mode == 0)
        {
            if (key_down == 1)
            {
                seg_disp_mode = 0;
                temp_disp_mode = 0;
            }
            if (key_down == 2)
            {
                seg_disp_mode = 3;
                pa_disp_mode = 0;
            }
            if (key_down == 4)
            {
                pid_disp_mode = 1;
                // pid_set_temp_100x = temp_100x - 50;
            }
        }
        else if (pid_disp_mode == 1)
        {
            if (pid_temp_ready)
            {
                pid_temp_ready = 0;
                pwm_compare = pid_calculate(temp_100x, pid_set_temp_100x);
            }
            if (key_down == 3)
            {
                pid_disp_mode = 0;
                pwm_compare = 0;
            }
        }
    }
    break;
    }
}

void seg_proc(void)
{

    if (seg_disp_mode == 0)
    {
        seg_buf[4] = 12;
        seg_buf[5] = 13;
        seg_buf[6] = 11;
        seg_buf[7] = 10;

        if (temp_disp_mode == 0)
        {
            seg_buf[0] = 10;
            seg_buf[1] = 10;
            seg_buf[2] = 10;
            seg_buf[3] = 10;
            seg_point[1] = 0;
        }
        else
        {
            seg_buf[0] = temp_100x / 1000 % 10;
            seg_buf[1] = temp_100x / 100 % 10;
            seg_buf[2] = temp_100x / 10 % 10;
            seg_buf[3] = temp_100x % 10;

            seg_point[1] = 1;
        }
    }
    else if (seg_disp_mode == 1)
    {
        seg_point[1] = 0;
        if (motor_test_disp == 0)
        {
            seg_buf[4] = 14;
            seg_buf[5] = 15;
            seg_buf[6] = 16;
            seg_buf[7] = 11;
            seg_buf[0] = 10;
            seg_buf[1] = 10;
            seg_buf[2] = 10;
            seg_buf[3] = 10;
        }
        else if (motor_test_disp == 1)
        {
            seg_buf[4] = 14;
            seg_buf[5] = 11;
            seg_buf[6] = 10;
            seg_buf[7] = pwm_set_index % 10;
            seg_buf[0] = 10;
            seg_buf[1] = 10;
            seg_buf[2] = pwm_set[pwm_set_index] / 10 % 10;
            seg_buf[3] = pwm_set[pwm_set_index] % 10;
        }
        else if (motor_test_disp == 2)
        {
            seg_buf[4] = 10;
            seg_buf[5] = 10;
            seg_buf[6] = pwm_set[pwm_set_index] / 10 % 10;
            seg_buf[7] = pwm_set[pwm_set_index] % 10;
            seg_buf[0] = (input_password[0] == 10) ? 10 : input_password[0] % 10;
            seg_buf[1] = (input_password[1] == 10) ? 10 : input_password[1] % 10;
            seg_buf[2] = (input_password[2] == 10) ? 10 : input_password[2] % 10;
            seg_buf[3] = (input_password[3] == 10) ? 10 : input_password[3] % 10;
        }
        else if (motor_test_disp == 3)
        {
            seg_buf[4] = 14;
            seg_buf[5] = 15;
            seg_buf[6] = 16;
            seg_buf[7] = 11;
            seg_buf[0] = 10;
            seg_buf[1] = 10;
            seg_buf[2] = pwm_set[pwm_set_index] / 10 % 10;
            seg_buf[3] = pwm_set[pwm_set_index] % 10;
        }
    }
    else if (seg_disp_mode == 2)
    { // 电机调速界面
        if (motor_speed_disp == 0)
        {
            seg_buf[4] = 17;
            seg_buf[5] = 18;
            seg_buf[6] = 16;
            seg_buf[7] = 11;
            seg_buf[0] = 10;
            seg_buf[1] = 10;
            seg_buf[2] = 10;
            seg_buf[3] = 10;
            seg_point[5] = 0; // 温度显示的小数点
        }
        else if (motor_speed_disp == 1)
        {
            seg_buf[4] = temp_100x / 1000 % 10;
            seg_buf[5] = temp_100x / 100 % 10;
            seg_buf[6] = temp_100x / 10 % 10;
            seg_buf[7] = temp_100x % 10;
            seg_buf[0] = 10;
            seg_buf[1] = 10;
            seg_buf[2] = pwm_compare / 10 % 10;
            seg_buf[3] = pwm_compare % 10;

            seg_point[5] = 1; // 温度显示的小数点
        }
    }
    else if (seg_disp_mode == 3)
    {
        seg_point[5] = 0; // 温度显示的小数点

        if (pa_disp_mode == 0)
        {
            seg_buf[4] = 13;
            seg_buf[5] = 19;
            seg_buf[6] = 11;
            seg_buf[7] = 10;
            seg_buf[0] = 10;
            seg_buf[1] = 10;
            seg_buf[2] = 10;
            seg_buf[3] = 10;
            seg_point[2] = 0; // 在第二位数后显示小数点
        }
        else if (pa_disp_mode == 1)
        {
            seg_buf[4] = 13;
            seg_buf[5] = 19;
            seg_buf[6] = 11;
            seg_buf[7] = 10;
            seg_buf[0] = 10;
            seg_buf[1] = 14;
            seg_buf[2] = 15;
            seg_buf[3] = 16;
        }
        else if (pa_disp_mode == 2)
        {
            seg_buf[4] = 13;
            seg_buf[5] = 19;
            seg_buf[6] = 11;
            seg_buf[7] = 10;
            seg_buf[0] = 10;
            seg_buf[1] = 17;
            seg_buf[2] = 18;
            seg_buf[3] = 16;
        }
        else if (pa_disp_mode == 3)
        {
            seg_buf[4] = 13;
            seg_buf[5] = 11;
            seg_buf[6] = 10;
            seg_buf[7] = pwm_set_index % 10;
            seg_buf[0] = 10;
            seg_buf[1] = 10;
            seg_buf[2] = pwm_set[pwm_set_index] / 10 % 10;
            seg_buf[3] = pwm_set[pwm_set_index] % 10;
        }
        else if (pa_disp_mode == 4)
        {
            seg_buf[4] = 19;
            seg_buf[5] = 11;
            seg_buf[6] = 10;
            seg_buf[7] = pwm_set_index % 10;
            seg_buf[0] = 10;
            seg_buf[1] = 10;
            seg_buf[2] = pwm_set[pwm_set_index] / 10 % 10;
            seg_buf[3] = pwm_set[pwm_set_index] % 10;
        }
        else if (pa_disp_mode == 5)
        {
            seg_buf[4] = 13;
            seg_buf[5] = 19;
            seg_buf[6] = 11;
            seg_buf[7] = 20;
            seg_buf[0] = 10;
            seg_buf[1] = 10;
            seg_buf[2] = temp_down_100x_ctrl / 1000 % 10;
            seg_buf[3] = temp_down_100x_ctrl / 100 % 10;
        }
        else if (pa_disp_mode == 6)
        {
            seg_buf[4] = 13;
            seg_buf[5] = 19;
            seg_buf[6] = 11;
            seg_buf[7] = 21;
            seg_buf[0] = 10;
            seg_buf[1] = 10;
            seg_buf[2] = temp_up_100x_ctrl / 1000 % 10;
            seg_buf[3] = temp_up_100x_ctrl / 100 % 10;
        }
        else if (pa_disp_mode == 7)
        {
            seg_buf[4] = 19;
            seg_buf[5] = 11;
            seg_buf[6] = 10;
            seg_buf[7] = 20;
            seg_buf[0] = 10;
            seg_buf[1] = 10;
            seg_buf[2] = temp_down_100x_ctrl / 1000 % 10;
            seg_buf[3] = temp_down_100x_ctrl / 100 % 10;
        }
        else if (pa_disp_mode == 8)
        {
            seg_buf[4] = 19;
            seg_buf[5] = 11;
            seg_buf[6] = 10;
            seg_buf[7] = 21;
            seg_buf[0] = 10;
            seg_buf[1] = 10;
            seg_buf[2] = temp_up_100x_ctrl / 1000 % 10;
            seg_buf[3] = temp_up_100x_ctrl / 100 % 10;
        }
        else if (pa_disp_mode == 9)
        {
            seg_buf[4] = 13;
            seg_buf[5] = 19;
            seg_buf[6] = 11;
            seg_buf[7] = 10;
            seg_buf[0] = 10;
            seg_buf[1] = 13;
            seg_buf[2] = 1;
            seg_buf[3] = 22;
            seg_point[2] = 0; // 在第二位数后显示小数点
        }
        else if (pa_disp_mode == 10)
        {
            seg_buf[4] = 19;
            seg_buf[5] = 11;
            seg_buf[6] = 10;
            seg_buf[7] = 13;
            seg_buf[0] = 10;
            seg_buf[1] = pid_set_temp_100x_ctrl / 1000 % 10;
            seg_buf[2] = pid_set_temp_100x_ctrl / 100 % 10;
            seg_buf[3] = pid_set_temp_100x_ctrl / 10 % 10;
            // 设置小数点
            seg_point[2] = 1; // 在第二位数后显示小数点
        }
    }
    else if (seg_disp_mode == 4)
    {
        seg_point[1] = 0; // 小数点位置
        if (pid_disp_mode == 0)
        {
            seg_buf[4] = 13;
            seg_buf[5] = 1;
            seg_buf[6] = 22;
            seg_buf[7] = 11;
            seg_buf[0] = 10;
            seg_buf[1] = 10;
            seg_buf[2] = 10;
            seg_buf[3] = 10;
            seg_point[5] = 0; // 温度显示的小数点
        }
        else if (pid_disp_mode == 1)
        {
            seg_buf[4] = temp_100x / 1000 % 10;
            seg_buf[5] = temp_100x / 100 % 10;
            seg_buf[6] = temp_100x / 10 % 10;
            seg_buf[7] = temp_100x % 10;
            seg_buf[0] = 10;
            seg_buf[1] = 10;
            seg_buf[2] = pwm_compare / 10 % 10;
            seg_buf[3] = pwm_compare % 10;

            seg_point[5] = 1; // 温度显示的小数点
        }
    }
}
void get_temperature()
{
    EA = 0;
    temp_100x = read_temperature() * 100;
    EA = 1;
    pid_temp_ready = 1; // 标记有新温度采样，供PID计算
}

void Timer0_Init(void) // 1毫秒@12.000MHz
{
    // AUXR &= 0x7F;		//定时器时钟12T模式
    TMOD &= 0xF0; // 设置定时器模式
    TMOD |= 0x01; // 设置定时器模式
    TL0 = 0x18;   // 设置定时初值
    TH0 = 0xFC;   // 设置定时初值
    TF0 = 0;      // 清除TF0标志
    TR0 = 1;      // 定时器0开始计时
    ET0 = 1;
    EA = 1;
}

void timer0_isr() interrupt 1
{
    TL0 = 0x18; // 设置定时初值
    TH0 = 0xFC; // 设置定时初值
    uwtick++;
    uart_tick++;
    seg_pos = (++seg_pos) % 8;
    if ((key1_long_press_flag == 1) || (key2_long_press_flag == 1))
    {
        if (++timer1000ms >= 1000)
        {
            timer1000ms = 1001;
        }
    }
    else
    {
        timer1000ms = 0;
    }
    pwm_period = (++pwm_period) % 100;
    if (pwm_period < pwm_compare && pwm_compare > 7)
    {
        Motor(1);
    }
    else
    {
        Motor(0);
    }
    // if (seg_disp_mode == 4) // pid显示模式
    // {
    //     if (pid_disp_mode == 1)
    //     {
    //         if (++counter >= 100)
    //         {
    //             counter = 0;
    //             pwm_compare = PID_Calculate(&temperature_pid, temp_100x);
    //         }
    //     }
    // }
}
void uart1_isr() interrupt 4
{
    unsigned char recv_char;
    if (RI)
    {
        recv_char = SBUF;
        RI = 0;

        // 直接处理命令
        if (recv_char == 'T' || recv_char == 't')
        {
            printf("Temp:%.2f\r\n", (float)(temp_100x) / 100.0);
        }
        else if (recv_char == 'P' || recv_char == 'p')
        {
            printf("PWM:%bu\r\n", pwm_compare);
        }
    }
}
typedef struct
{
    void (*func)(void);
    long int task_rate;
    long int last_run;
} task_t;
xdata task_t scheduler_list[] = {
    {key_proc, 10, 0},
    {get_temperature, 300, 0},
    {seg_proc, 200, 0},
};
unsigned char task_num;
void scheduler_init()
{
    task_num = sizeof(scheduler_list) / sizeof(task_t);
}
void scheduler_run()
{
    unsigned char i;
    for (i = 0; i < task_num; i++)
    {
        unsigned long int now = uwtick;
        if (now - scheduler_list[i].last_run >= scheduler_list[i].task_rate)
        {
            scheduler_list[i].last_run = now;
            scheduler_list[i].func();
        }
    }
}

void main()
{
    unsigned char temp1 = 0;
    unsigned char temp2 = 0;

    UartInit();

    temp1 = at24c16_readbyte(0x06);
    if (temp1 == eeproom_lock)
    {
        temp_down_100x = at24c16_readbyte(0x01) * 100;
        temp_up_100x = at24c16_readbyte(0x02) * 100;
    }
    else
    {
        temp_down_100x = 2600;
        temp_up_100x = 3000;
    }
    temp_down_100x_ctrl = temp_down_100x;
    temp_up_100x_ctrl = temp_up_100x;
    
    temp2 = at24c16_readbyte(0x07);
    if (temp2 == eeproom_lock)
    { 
        pid_set_temp_100x = at24c16_readbyte(0x03) * 100 + at24c16_readbyte(0x04);
        printf("Set PID at Temp %d", pid_set_temp_100x);
    }
    else
    {
        pid_set_temp_100x = 2560;
    }
    pid_set_temp_100x_ctrl = pid_set_temp_100x;

    seg_init();
    scheduler_init();
    Timer0_Init();

    while (1)
    {
        EA = 0;
        seg_disp(seg_pos, seg_buf[seg_pos], seg_point[seg_pos]);
        EA = 1;
        scheduler_run();
    }
}
